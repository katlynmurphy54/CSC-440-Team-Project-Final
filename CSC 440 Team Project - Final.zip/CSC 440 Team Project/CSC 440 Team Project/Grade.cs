﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC_440_Team_Project
{
    public class Grade
    {
        public String coursePrefix;
        public String courseNum;
        public String courseYear;
        public String semester;
        public String hours;
        public String studentID;
        public String grade;

        public Grade() { }
        public Grade(String coursePrefix, String courseNum, String courseYear, String semester, String hours, String studentID)
        {
            this.coursePrefix = coursePrefix;
            this.courseNum = courseNum;
            this.courseYear = courseYear;
            this.semester = semester;
            this.hours = hours;
            this.studentID = studentID;
        }

        //return true if the entered grade conflicts with this one
        public Boolean checkConflict(Grade g)
        {
            return ((coursePrefix != g.coursePrefix) || (courseNum != g.courseNum)
                || (courseYear != g.courseYear) || (semester != g.semester)
                || (studentID != g.studentID)) && (!grade.Equals("_") && g.grade.Equals("_"));
        }

        //return true if the entered grade conflicts with this one
        //causes conflict if one grade has been deleted/edited
        public Boolean checkConflictDeleted(Grade g)
        {
            return ((coursePrefix != g.coursePrefix) || (courseNum != g.courseNum)
                || (courseYear != g.courseYear) || (semester != g.semester)
                || (studentID != g.studentID));
        }

        //can be set from A, B, C, D, F or _
        //_ marks a deleted grade
        public void setGrade(String g)
        {
            grade = g;
        }
    }
}
