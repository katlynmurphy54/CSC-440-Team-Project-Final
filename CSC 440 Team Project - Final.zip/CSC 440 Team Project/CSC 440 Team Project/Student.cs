﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC_440_Team_Project
{
    public class Student
    {
        public String studentID;
        public String name;
        public double GPA;
        public Student() { }

        public Student(String studentID, String name, double GPA)
        {
            this.studentID = studentID;
            this.name = name;
            this.GPA = GPA;
        }

        public void setStudent(String sID, String sNa)
        {
            studentID = sID;
            name = sNa;
        }

        public void setGPA(double g)
        {
            GPA = g;
        }
    }
}
