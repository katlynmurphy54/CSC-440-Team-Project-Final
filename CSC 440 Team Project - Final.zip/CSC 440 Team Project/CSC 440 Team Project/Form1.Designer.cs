﻿
namespace CSC_440_Team_Project
{
    partial class MainMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addGradeButton = new System.Windows.Forms.Button();
            this.deleteGradeButton = new System.Windows.Forms.Button();
            this.generateTranscriptButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.studentIDPanel = new System.Windows.Forms.Panel();
            this.addStudentButton = new System.Windows.Forms.Button();
            this.continueButton = new System.Windows.Forms.Button();
            this.studentIDTextbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.editGradeButton = new System.Windows.Forms.Button();
            this.studentInfoPanel = new System.Windows.Forms.Panel();
            this.creditHoursTextbox = new System.Windows.Forms.TextBox();
            this.creditHoursLabel = new System.Windows.Forms.Label();
            this.coursePrefixTextbox = new System.Windows.Forms.TextBox();
            this.gradesDataGridView = new System.Windows.Forms.DataGridView();
            this.courseNumberTextbox = new System.Windows.Forms.TextBox();
            this.gradeTextbox = new System.Windows.Forms.TextBox();
            this.semesterTextbox = new System.Windows.Forms.TextBox();
            this.yearTextbox = new System.Windows.Forms.TextBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.courseNumberLabel = new System.Windows.Forms.Label();
            this.semesterLabel = new System.Windows.Forms.Label();
            this.gradeLabel = new System.Windows.Forms.Label();
            this.prefixLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.studentIDLabel = new System.Windows.Forms.Label();
            this.addStudentPanel = new System.Windows.Forms.Panel();
            this.newStudentSave = new System.Windows.Forms.Button();
            this.newStudentLastNameTextbox = new System.Windows.Forms.TextBox();
            this.newStudentLastNameLabel = new System.Windows.Forms.Label();
            this.firstNameTextbox = new System.Windows.Forms.TextBox();
            this.newStudentFirstNameLabel = new System.Windows.Forms.Label();
            this.newStudentIDTextbox = new System.Windows.Forms.TextBox();
            this.newStudentIDLabel = new System.Windows.Forms.Label();
            this.studentIDPanel.SuspendLayout();
            this.studentInfoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gradesDataGridView)).BeginInit();
            this.addStudentPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // addGradeButton
            // 
            this.addGradeButton.Location = new System.Drawing.Point(12, 70);
            this.addGradeButton.Name = "addGradeButton";
            this.addGradeButton.Size = new System.Drawing.Size(115, 44);
            this.addGradeButton.TabIndex = 0;
            this.addGradeButton.Text = "Add Grade";
            this.addGradeButton.UseVisualStyleBackColor = true;
            this.addGradeButton.Click += new System.EventHandler(this.addGradeButton_Click);
            // 
            // deleteGradeButton
            // 
            this.deleteGradeButton.Location = new System.Drawing.Point(12, 168);
            this.deleteGradeButton.Name = "deleteGradeButton";
            this.deleteGradeButton.Size = new System.Drawing.Size(115, 44);
            this.deleteGradeButton.TabIndex = 2;
            this.deleteGradeButton.Text = "Delete Grade";
            this.deleteGradeButton.UseVisualStyleBackColor = true;
            this.deleteGradeButton.Click += new System.EventHandler(this.deleteGradeButton_Click);
            // 
            // generateTranscriptButton
            // 
            this.generateTranscriptButton.Location = new System.Drawing.Point(12, 217);
            this.generateTranscriptButton.Name = "generateTranscriptButton";
            this.generateTranscriptButton.Size = new System.Drawing.Size(115, 44);
            this.generateTranscriptButton.TabIndex = 3;
            this.generateTranscriptButton.Text = "Generate Transcript";
            this.generateTranscriptButton.UseVisualStyleBackColor = true;
            this.generateTranscriptButton.Click += new System.EventHandler(this.generateTranscriptButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(259, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Welcome to EKU Registar\'s Office Gradebook!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Please select an option:";
            // 
            // studentIDPanel
            // 
            this.studentIDPanel.Controls.Add(this.addStudentButton);
            this.studentIDPanel.Controls.Add(this.continueButton);
            this.studentIDPanel.Controls.Add(this.studentIDTextbox);
            this.studentIDPanel.Controls.Add(this.label3);
            this.studentIDPanel.Location = new System.Drawing.Point(177, 54);
            this.studentIDPanel.Name = "studentIDPanel";
            this.studentIDPanel.Size = new System.Drawing.Size(336, 230);
            this.studentIDPanel.TabIndex = 6;
            // 
            // addStudentButton
            // 
            this.addStudentButton.Location = new System.Drawing.Point(6, 163);
            this.addStudentButton.Name = "addStudentButton";
            this.addStudentButton.Size = new System.Drawing.Size(115, 44);
            this.addStudentButton.TabIndex = 9;
            this.addStudentButton.Text = "Add Student";
            this.addStudentButton.UseVisualStyleBackColor = true;
            this.addStudentButton.Click += new System.EventHandler(this.addStudentButton_Click);
            // 
            // continueButton
            // 
            this.continueButton.Location = new System.Drawing.Point(202, 163);
            this.continueButton.Name = "continueButton";
            this.continueButton.Size = new System.Drawing.Size(115, 44);
            this.continueButton.TabIndex = 8;
            this.continueButton.Text = "Continue";
            this.continueButton.UseVisualStyleBackColor = true;
            this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
            // 
            // studentIDTextbox
            // 
            this.studentIDTextbox.Location = new System.Drawing.Point(150, 29);
            this.studentIDTextbox.MaxLength = 9;
            this.studentIDTextbox.Name = "studentIDTextbox";
            this.studentIDTextbox.Size = new System.Drawing.Size(167, 20);
            this.studentIDTextbox.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Please enter the Student ID:";
            // 
            // editGradeButton
            // 
            this.editGradeButton.Location = new System.Drawing.Point(12, 120);
            this.editGradeButton.Name = "editGradeButton";
            this.editGradeButton.Size = new System.Drawing.Size(115, 44);
            this.editGradeButton.TabIndex = 7;
            this.editGradeButton.Text = "Edit Grade";
            this.editGradeButton.UseVisualStyleBackColor = true;
            this.editGradeButton.Click += new System.EventHandler(this.editGradeButton_Click);
            // 
            // studentInfoPanel
            // 
            this.studentInfoPanel.Controls.Add(this.creditHoursTextbox);
            this.studentInfoPanel.Controls.Add(this.creditHoursLabel);
            this.studentInfoPanel.Controls.Add(this.coursePrefixTextbox);
            this.studentInfoPanel.Controls.Add(this.gradesDataGridView);
            this.studentInfoPanel.Controls.Add(this.courseNumberTextbox);
            this.studentInfoPanel.Controls.Add(this.gradeTextbox);
            this.studentInfoPanel.Controls.Add(this.semesterTextbox);
            this.studentInfoPanel.Controls.Add(this.yearTextbox);
            this.studentInfoPanel.Controls.Add(this.saveButton);
            this.studentInfoPanel.Controls.Add(this.courseNumberLabel);
            this.studentInfoPanel.Controls.Add(this.semesterLabel);
            this.studentInfoPanel.Controls.Add(this.gradeLabel);
            this.studentInfoPanel.Controls.Add(this.prefixLabel);
            this.studentInfoPanel.Controls.Add(this.yearLabel);
            this.studentInfoPanel.Controls.Add(this.nameLabel);
            this.studentInfoPanel.Controls.Add(this.studentIDLabel);
            this.studentInfoPanel.Location = new System.Drawing.Point(177, 54);
            this.studentInfoPanel.Name = "studentInfoPanel";
            this.studentInfoPanel.Size = new System.Drawing.Size(508, 391);
            this.studentInfoPanel.TabIndex = 8;
            // 
            // creditHoursTextbox
            // 
            this.creditHoursTextbox.Location = new System.Drawing.Point(391, 130);
            this.creditHoursTextbox.MaxLength = 1;
            this.creditHoursTextbox.Name = "creditHoursTextbox";
            this.creditHoursTextbox.Size = new System.Drawing.Size(100, 20);
            this.creditHoursTextbox.TabIndex = 18;
            // 
            // creditHoursLabel
            // 
            this.creditHoursLabel.AutoSize = true;
            this.creditHoursLabel.Location = new System.Drawing.Point(274, 133);
            this.creditHoursLabel.Name = "creditHoursLabel";
            this.creditHoursLabel.Size = new System.Drawing.Size(96, 13);
            this.creditHoursLabel.TabIndex = 17;
            this.creditHoursLabel.Text = "Enter Credit Hours:";
            // 
            // coursePrefixTextbox
            // 
            this.coursePrefixTextbox.Location = new System.Drawing.Point(109, 67);
            this.coursePrefixTextbox.MaxLength = 3;
            this.coursePrefixTextbox.Name = "coursePrefixTextbox";
            this.coursePrefixTextbox.Size = new System.Drawing.Size(100, 20);
            this.coursePrefixTextbox.TabIndex = 16;
            // 
            // gradesDataGridView
            // 
            this.gradesDataGridView.AllowUserToAddRows = false;
            this.gradesDataGridView.AllowUserToDeleteRows = false;
            this.gradesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gradesDataGridView.Location = new System.Drawing.Point(3, 226);
            this.gradesDataGridView.Name = "gradesDataGridView";
            this.gradesDataGridView.ReadOnly = true;
            this.gradesDataGridView.RowHeadersVisible = false;
            this.gradesDataGridView.Size = new System.Drawing.Size(505, 146);
            this.gradesDataGridView.TabIndex = 15;
            // 
            // courseNumberTextbox
            // 
            this.courseNumberTextbox.Location = new System.Drawing.Point(391, 67);
            this.courseNumberTextbox.MaxLength = 3;
            this.courseNumberTextbox.Name = "courseNumberTextbox";
            this.courseNumberTextbox.Size = new System.Drawing.Size(100, 20);
            this.courseNumberTextbox.TabIndex = 14;
            // 
            // gradeTextbox
            // 
            this.gradeTextbox.Location = new System.Drawing.Point(109, 130);
            this.gradeTextbox.MaxLength = 1;
            this.gradeTextbox.Name = "gradeTextbox";
            this.gradeTextbox.Size = new System.Drawing.Size(100, 20);
            this.gradeTextbox.TabIndex = 13;
            // 
            // semesterTextbox
            // 
            this.semesterTextbox.Location = new System.Drawing.Point(391, 98);
            this.semesterTextbox.Name = "semesterTextbox";
            this.semesterTextbox.Size = new System.Drawing.Size(100, 20);
            this.semesterTextbox.TabIndex = 11;
            // 
            // yearTextbox
            // 
            this.yearTextbox.Location = new System.Drawing.Point(109, 98);
            this.yearTextbox.MaxLength = 4;
            this.yearTextbox.Name = "yearTextbox";
            this.yearTextbox.Size = new System.Drawing.Size(100, 20);
            this.yearTextbox.TabIndex = 10;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(376, 163);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(115, 44);
            this.saveButton.TabIndex = 9;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // courseNumberLabel
            // 
            this.courseNumberLabel.AutoSize = true;
            this.courseNumberLabel.Location = new System.Drawing.Point(274, 70);
            this.courseNumberLabel.Name = "courseNumberLabel";
            this.courseNumberLabel.Size = new System.Drawing.Size(111, 13);
            this.courseNumberLabel.TabIndex = 7;
            this.courseNumberLabel.Text = "Enter Course Number:";
            // 
            // semesterLabel
            // 
            this.semesterLabel.AutoSize = true;
            this.semesterLabel.Location = new System.Drawing.Point(274, 101);
            this.semesterLabel.Name = "semesterLabel";
            this.semesterLabel.Size = new System.Drawing.Size(82, 13);
            this.semesterLabel.TabIndex = 6;
            this.semesterLabel.Text = "Enter Semester:";
            // 
            // gradeLabel
            // 
            this.gradeLabel.AutoSize = true;
            this.gradeLabel.Location = new System.Drawing.Point(3, 133);
            this.gradeLabel.Name = "gradeLabel";
            this.gradeLabel.Size = new System.Drawing.Size(67, 13);
            this.gradeLabel.TabIndex = 5;
            this.gradeLabel.Text = "Enter Grade:";
            // 
            // prefixLabel
            // 
            this.prefixLabel.AutoSize = true;
            this.prefixLabel.Location = new System.Drawing.Point(3, 70);
            this.prefixLabel.Name = "prefixLabel";
            this.prefixLabel.Size = new System.Drawing.Size(100, 13);
            this.prefixLabel.TabIndex = 4;
            this.prefixLabel.Text = "Enter Course Prefix:";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Location = new System.Drawing.Point(3, 101);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(60, 13);
            this.yearLabel.TabIndex = 3;
            this.yearLabel.Text = "Enter Year:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(188, 13);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(111, 13);
            this.nameLabel.TabIndex = 1;
            this.nameLabel.Text = "First Name Last Name";
            // 
            // studentIDLabel
            // 
            this.studentIDLabel.AutoSize = true;
            this.studentIDLabel.Location = new System.Drawing.Point(201, 29);
            this.studentIDLabel.Name = "studentIDLabel";
            this.studentIDLabel.Size = new System.Drawing.Size(58, 13);
            this.studentIDLabel.TabIndex = 0;
            this.studentIDLabel.Text = "Student ID";
            // 
            // addStudentPanel
            // 
            this.addStudentPanel.Controls.Add(this.newStudentSave);
            this.addStudentPanel.Controls.Add(this.newStudentLastNameTextbox);
            this.addStudentPanel.Controls.Add(this.newStudentLastNameLabel);
            this.addStudentPanel.Controls.Add(this.firstNameTextbox);
            this.addStudentPanel.Controls.Add(this.newStudentFirstNameLabel);
            this.addStudentPanel.Controls.Add(this.newStudentIDTextbox);
            this.addStudentPanel.Controls.Add(this.newStudentIDLabel);
            this.addStudentPanel.Location = new System.Drawing.Point(177, 53);
            this.addStudentPanel.Name = "addStudentPanel";
            this.addStudentPanel.Size = new System.Drawing.Size(238, 221);
            this.addStudentPanel.TabIndex = 9;
            // 
            // newStudentSave
            // 
            this.newStudentSave.Location = new System.Drawing.Point(109, 164);
            this.newStudentSave.Name = "newStudentSave";
            this.newStudentSave.Size = new System.Drawing.Size(115, 44);
            this.newStudentSave.TabIndex = 19;
            this.newStudentSave.Text = "Save Student";
            this.newStudentSave.UseVisualStyleBackColor = true;
            this.newStudentSave.Click += new System.EventHandler(this.newStudentSave_Click);
            // 
            // newStudentLastNameTextbox
            // 
            this.newStudentLastNameTextbox.Location = new System.Drawing.Point(124, 91);
            this.newStudentLastNameTextbox.Name = "newStudentLastNameTextbox";
            this.newStudentLastNameTextbox.Size = new System.Drawing.Size(100, 20);
            this.newStudentLastNameTextbox.TabIndex = 18;
            // 
            // newStudentLastNameLabel
            // 
            this.newStudentLastNameLabel.AutoSize = true;
            this.newStudentLastNameLabel.Location = new System.Drawing.Point(18, 95);
            this.newStudentLastNameLabel.Name = "newStudentLastNameLabel";
            this.newStudentLastNameLabel.Size = new System.Drawing.Size(89, 13);
            this.newStudentLastNameLabel.TabIndex = 17;
            this.newStudentLastNameLabel.Text = "Enter Last Name:";
            // 
            // firstNameTextbox
            // 
            this.firstNameTextbox.Location = new System.Drawing.Point(124, 52);
            this.firstNameTextbox.Name = "firstNameTextbox";
            this.firstNameTextbox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextbox.TabIndex = 16;
            // 
            // newStudentFirstNameLabel
            // 
            this.newStudentFirstNameLabel.AutoSize = true;
            this.newStudentFirstNameLabel.Location = new System.Drawing.Point(18, 56);
            this.newStudentFirstNameLabel.Name = "newStudentFirstNameLabel";
            this.newStudentFirstNameLabel.Size = new System.Drawing.Size(88, 13);
            this.newStudentFirstNameLabel.TabIndex = 15;
            this.newStudentFirstNameLabel.Text = "Enter First Name:";
            // 
            // newStudentIDTextbox
            // 
            this.newStudentIDTextbox.Location = new System.Drawing.Point(124, 15);
            this.newStudentIDTextbox.MaxLength = 9;
            this.newStudentIDTextbox.Name = "newStudentIDTextbox";
            this.newStudentIDTextbox.Size = new System.Drawing.Size(100, 20);
            this.newStudentIDTextbox.TabIndex = 14;
            // 
            // newStudentIDLabel
            // 
            this.newStudentIDLabel.AutoSize = true;
            this.newStudentIDLabel.Location = new System.Drawing.Point(18, 19);
            this.newStudentIDLabel.Name = "newStudentIDLabel";
            this.newStudentIDLabel.Size = new System.Drawing.Size(89, 13);
            this.newStudentIDLabel.TabIndex = 13;
            this.newStudentIDLabel.Text = "Enter Student ID:";
            // 
            // MainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 457);
            this.Controls.Add(this.editGradeButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.generateTranscriptButton);
            this.Controls.Add(this.deleteGradeButton);
            this.Controls.Add(this.addGradeButton);
            this.Controls.Add(this.addStudentPanel);
            this.Controls.Add(this.studentIDPanel);
            this.Controls.Add(this.studentInfoPanel);
            this.Name = "MainMenuForm";
            this.Text = "EKU Registar\'s Gradebook";
            this.studentIDPanel.ResumeLayout(false);
            this.studentIDPanel.PerformLayout();
            this.studentInfoPanel.ResumeLayout(false);
            this.studentInfoPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gradesDataGridView)).EndInit();
            this.addStudentPanel.ResumeLayout(false);
            this.addStudentPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addGradeButton;
        private System.Windows.Forms.Button deleteGradeButton;
        private System.Windows.Forms.Button generateTranscriptButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel studentIDPanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button editGradeButton;
        private System.Windows.Forms.Button continueButton;
        private System.Windows.Forms.TextBox studentIDTextbox;
        private System.Windows.Forms.Button addStudentButton;
        private System.Windows.Forms.Panel studentInfoPanel;
        private System.Windows.Forms.Label courseNumberLabel;
        private System.Windows.Forms.Label semesterLabel;
        private System.Windows.Forms.Label gradeLabel;
        private System.Windows.Forms.Label prefixLabel;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label studentIDLabel;
        private System.Windows.Forms.TextBox yearTextbox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.TextBox courseNumberTextbox;
        private System.Windows.Forms.TextBox gradeTextbox;
        private System.Windows.Forms.TextBox semesterTextbox;
        private System.Windows.Forms.DataGridView gradesDataGridView;
        private System.Windows.Forms.Panel addStudentPanel;
        private System.Windows.Forms.Button newStudentSave;
        private System.Windows.Forms.TextBox newStudentLastNameTextbox;
        private System.Windows.Forms.Label newStudentLastNameLabel;
        private System.Windows.Forms.TextBox firstNameTextbox;
        private System.Windows.Forms.Label newStudentFirstNameLabel;
        private System.Windows.Forms.TextBox newStudentIDTextbox;
        private System.Windows.Forms.Label newStudentIDLabel;
        private System.Windows.Forms.TextBox coursePrefixTextbox;
        private System.Windows.Forms.TextBox creditHoursTextbox;
        private System.Windows.Forms.Label creditHoursLabel;
    }
}

