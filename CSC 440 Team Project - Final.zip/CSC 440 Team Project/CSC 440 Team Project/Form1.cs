﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using MySql.Data.MySqlClient;
using iTextSharp.text.pdf;
using iTextSharp.text;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace CSC_440_Team_Project
{
    public partial class MainMenuForm : Form
    {

        public MainMenuForm()
        {
            InitializeComponent();
            //import grades on initialization
            string connStr;
            MySqlConnection conn;


            //set up excel book
            string[] dir = System.IO.Directory.GetDirectories(@"c:\", "Grades Folder*");
            for (int i = 0; i < dir.Length; i++)
            {
                String[] dir2 = System.IO.Directory.GetDirectories(dir[i], "Grades*");
                for (int j = 0; j < dir2.Length; j++)
                {
                    string[] files = Directory.GetFiles(dir2[j]);
                    foreach (string file in files)
                    {
                        //Console.WriteLine(file);
                        string[] attr = fileNameBreakdown(file);
                        foreach (String comp in attr)
                        {
                            Console.WriteLine(comp);
                        }

                        Excel.Application xlApp = new Excel.Application();
                        Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(file); //specify file path of excel book
                        Excel.Worksheet xlWorksheet = xlWorkbook.Sheets[1]; //index of the sheet that needs to be read
                        Excel.Range xlRange = xlWorksheet.UsedRange;

                        int rowCount = xlRange.Rows.Count;
                        int colCount = xlRange.Columns.Count;

                        DataTable studentInfo = new DataTable("Student Information");
                        DataTable studentGrades = new DataTable("Student Grades");
                        DataTable CourseHours = new DataTable("Course Hours");

                        // studentInfo
                        studentInfo.Columns.Add("name", typeof(String));
                        studentInfo.Columns.Add("studentID", typeof(String));
                        studentInfo.Columns.Add("GPA", typeof(String));

                        //read each cell of data for sheet 1

                        for (int k = 2; k <= rowCount; k++) //indexes in excel start at 1, not 0! Avoid 1st index 
                        {
                            DataRow row = studentInfo.NewRow();
                            //skip 'l' to provent confusion
                            for (int m = 1; m <= colCount; m++)
                            {
                                //new line
                                if (m == 1)
                                    Console.Write("\r\n");

                                //write the value to the console
                                if (xlRange.Cells[k, m] != null && xlRange.Cells[k, m].Value2 != null)
                                {
                                    row[m - 1] = xlRange.Cells[k, m].Value2;

                                    Console.Write(xlRange.Cells[k, m].Value2.ToString() + "\t");
                                }


                                //add useful things here!   
                            }
                            studentInfo.Rows.Add(row);
                        }

                        foreach (DataRow dataRow in studentInfo.Rows)
                        {

                            String[] student = new string[3];
                            int index = 0;


                            foreach (var item in dataRow.ItemArray)
                            {
                                // Console.Write(item);
                                student[index] = item.ToString();

                                index++;
                            }
                            Console.Write("Name = " + student[0] + " ID = " + student[1]);
                            //student[0] = name
                            //student[1] = ID
                            //student[2] = Grade


                            //Check if student is in database

                            DataTable myTable = new DataTable();
                            connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;"; //Server may need to be changed to 157.89.28.29
                            //connStr = "server=127.0.0.1;user=root;database=testing;port=3306;";
                            conn = new MySqlConnection(connStr);
                            try
                            {
                                Console.WriteLine("Connecting to MySQL...");
                                conn.Open();
                                //string sql = "Select * From michaelStudentInfo where Studentid = @id"; //SQL string to retrieve from the database
                                //string sql = "Select * from dhk_studentinfo where studentID = @studentID";
                                string sql = "Select * from michaelstudentinfo where studentID = @studentID";
                                MySqlCommand cmd = new MySqlCommand(sql, conn);
                                cmd.Parameters.AddWithValue("@studentID", student[1]);
                                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                                myAdapter.Fill(myTable);

                                if (myTable.Rows.Count == 0)
                                {
                                    //Student isn't found so add them
                                    //sql = "Insert into michaelStudentInfo (StudentID, Name, GPA) values (@StudentID, @Name, @GPA)"; //SQL string to retrieve from the database
                                    //sql = "Insert into dhk_studentinfo (studentID, name, overallGPA) values (@studentID, @name, @overallGPA)";
                                    sql = "Insert into michaelstudentinfo (StudentID, Name, GPA) values (@StudentID, @Name, @GPA)";
                                    cmd = new MySqlCommand(sql, conn);
                                    cmd.Parameters.AddWithValue("@Name", student[0]);
                                    cmd.Parameters.AddWithValue("@StudentID", student[1]);
                                    cmd.Parameters.AddWithValue("@GPA", 0);

                                    cmd.ExecuteNonQuery();

                                    DataTable myTable4 = new DataTable();

                                    //Check if everything except grade exists; The grade can be changed later if desired
                                    //sql = "SELECT * FROM michaelCourseHours where coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester"; //SQL string to retrieve from the database
                                    sql = "SELECT * FROM michaelcoursehours where coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester"; //SQL string to retrieve from the database
                                    cmd = new MySqlCommand(sql, conn);

                                    
                                    cmd.Parameters.AddWithValue("@coursePrefix", attr[0]);
                                    cmd.Parameters.AddWithValue("@courseNum", attr[3]);
                                    cmd.Parameters.AddWithValue("@courseYear", attr[2]);
                                    cmd.Parameters.AddWithValue("@semester", attr[1]);

                                    
                                    myAdapter = new MySqlDataAdapter(cmd);
                                    myAdapter.Fill(myTable4);

                                    //course is there so  add grade
                                    if (myTable4.Rows.Count != 0)
                                    {
                                        //Now add associated grade information
                                        //sql = "INSERT INTO michaelstudentgrades (studentID, coursePrefix, courseNum, grade, courseYear,semester) VALUES(@studentID, @coursePrefix, @courseNum, @grade, @courseYear, @semester)"; //SQL string to retrieve from the database
                                        sql = "INSERT INTO michaelstudentgrades (studentID, coursePrefix, courseNum, grade, courseYear, semester) VALUES (@studentID, @coursePrefix, @courseNum, @grade, @courseYear, @semester)"; //SQL string to retrieve from the database
                                        cmd = new MySqlCommand(sql, conn);
                                        
                                        cmd.Parameters.AddWithValue("@studentID", student[1]);                                       
                                        cmd.Parameters.AddWithValue("@coursePrefix", attr[0]);
                                        cmd.Parameters.AddWithValue("@courseNum", attr[3]);
                                        cmd.Parameters.AddWithValue("@grade", student[2]);
                                        cmd.Parameters.AddWithValue("@courseYear", attr[2]);
                                        cmd.Parameters.AddWithValue("@semester", attr[1]);
                                   
                                        cmd.ExecuteNonQuery();

                                    }
                                }
                                else
                                {
                                    //student exists so just add grade information after checking if it already exists

                                    DataTable myTable2 = new DataTable();

                                    //Check if everything except grade exists; The grade can be changed later if desired
                                    //sql = "SELECT * FROM michaelstudentgrades WHERE studentID = @studentID AND coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear And semester = @semester "; //SQL string to retrieve from the database
                                    sql = "SELECT * FROM michaelstudentgrades WHERE studentID = @studentID AND coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester "; //SQL string to retrieve from the database
                                    cmd = new MySqlCommand(sql, conn);
                                    
                                    cmd.Parameters.AddWithValue("@studentID", student[1]);
                                    cmd.Parameters.AddWithValue("@coursePrefix", attr[0]);
                                    cmd.Parameters.AddWithValue("@courseNum", attr[3]);
                                    cmd.Parameters.AddWithValue("@courseYear", attr[2]);
                                    cmd.Parameters.AddWithValue("@semester", attr[1]);

                                    
                                    myAdapter = new MySqlDataAdapter(cmd);
                                    myAdapter.Fill(myTable2);

                                    //grade isnt there so check if course info is there
                                    if (myTable2.Rows.Count == 0)
                                    {

                                        DataTable myTable3 = new DataTable();

                                        //Check if everything except grade exists; The grade can be changed later if desired
                                        //sql = "SELECT * FROM michaelCourseHours where coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester"; //SQL string to retrieve from the database
                                        sql = "SELECT * FROM dhk_courseinfo where coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester"; //SQL string to retrieve from the database
                                        cmd = new MySqlCommand(sql, conn);
                                        cmd = new MySqlCommand(sql, conn);
                                        
                                        cmd.Parameters.AddWithValue("@coursePrefix", attr[0]);
                                        cmd.Parameters.AddWithValue("@courseNum", attr[3]);
                                        cmd.Parameters.AddWithValue("@courseYear", attr[2]);
                                        cmd.Parameters.AddWithValue("@semester", attr[1]);

                                        myAdapter = new MySqlDataAdapter(cmd);
                                        myAdapter.Fill(myTable3);
                                        

                                        //course is there so add grade
                                        if (myTable3.Rows.Count != 0)
                                        {

                                            //now add grade
                                            //sql = "INSERT INTO michaelstudentgrades (studentID, coursePrefix, courseNum, grade, courseYear,semester) VALUES(@studentID, @coursePrefix, @courseNum, @grade, @courseYear, @semester)"; //SQL string to retrieve from the database
                                            sql = "INSERT INTO michaelstudentgrades (studentID, coursePrefix, courseNum, grade, courseYear, semester) VALUES (@studentID, @coursePrefix, @courseNum, @grade, @courseYear, @semester)"; //SQL string to retrieve from the database
                                            cmd = new MySqlCommand(sql, conn);
                                            cmd.Parameters.AddWithValue("@studentID", student[1]);
                                            
                                            cmd.Parameters.AddWithValue("@coursePrefix", attr[0]);
                                            cmd.Parameters.AddWithValue("@courseNum", attr[3]);
                                            cmd.Parameters.AddWithValue("@grade", student[2]);
                                            cmd.Parameters.AddWithValue("@courseYear", attr[2]);
                                            cmd.Parameters.AddWithValue("@semester", attr[1]);
                                           
                                            cmd.ExecuteNonQuery();
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }
                            conn.Close();
                        }


                        //cleanup
                        GC.Collect();
                        GC.WaitForPendingFinalizers();

                        //rule of thumb for releasing com objects:
                        //  never use two dots, all COM objects must be referenced and released individually
                        //  ex: [somthing].[something].[something] is bad

                        //release com objects to fully kill excel process from running in the background
                        Marshal.ReleaseComObject(xlRange);
                        Marshal.ReleaseComObject(xlWorksheet);

                        //close and release
                        xlWorkbook.Close();
                        Marshal.ReleaseComObject(xlWorkbook);

                        //quit and release
                        xlApp.Quit();
                        Marshal.ReleaseComObject(xlApp);
                    }

                }

            }
            MessageBox.Show("Grades imported on software startup successfully.", "Startup Success");

            //hide panels
            studentIDPanel.Visible = false;
            studentInfoPanel.Visible = false;
            addStudentPanel.Visible = false;

        } //end of set up excel book 

        //variables - need to use getters/setters
        public static string studentID = "";
        public static string firstName = "";
        public static string lastName = "";
        public static string name = "";
        public static string coursePrefix = "";
        public static string courseNum = "";
        public static string year = "";
        public static string grade = "";
        public static string semester = "";
        public static string hours = "";
        public static string validStudentID = "";
        public static string validCoursePrefix = "";
        public static string validCourseNumber = "";
        public static string validName = "";
        public static string validOverallGPA = "";
        public static string validSemester = "";
        public static string validYear = "";
        public static int count = 0;

        //add grade button clicked
        private void addGradeButton_Click(object sender, EventArgs e)
        {
            //panel visibility
            studentIDPanel.Visible = true;
            studentInfoPanel.Visible = false;
            addStudentButton.Visible = true;
            addStudentPanel.Visible = false;
            gradeTextbox.Visible = true;
            gradeLabel.Visible = true;
            saveButton.Text = "ADD GRADE";
            clearEnteredText();
            count = 1;
        }

        //edit grade button clicked
        private void editGradeButton_Click(object sender, EventArgs e)
        {
            //panel visibility
            studentIDPanel.Visible = true;
            studentInfoPanel.Visible = false;
            addStudentButton.Visible = false;
            addStudentPanel.Visible = false;
            gradeTextbox.Visible = true;
            gradeLabel.Visible = true;
            saveButton.Text = "EDIT GRADE";
            clearEnteredText();
            count = 2;
        }

        private void deleteGradeButton_Click(object sender, EventArgs e)
        {
            //panel visiblity
            studentIDPanel.Visible = true;
            studentInfoPanel.Visible = false;
            addStudentButton.Visible = false;
            addStudentPanel.Visible = false;
            gradeLabel.Visible = false;
            gradeTextbox.Visible = false;
            saveButton.Text = "DELETE GRADE";
            //saveButton.BackColor.
            clearEnteredText();
            count = 3;
        }

        private void generateTranscriptButton_Click(object sender, EventArgs e)
        {
            //panel visibility
            studentIDPanel.Visible = true;
            studentInfoPanel.Visible = false;
            addStudentButton.Visible = false;
            addStudentPanel.Visible = false;
            count = 4;
        }

        //student ID entered and continue button pressed
        private void continueButton_Click(object sender, EventArgs e)
        {
            //blank input validation
            if (studentIDTextbox.Text.Equals("") || studentIDTextbox.Text.Equals(" "))
            {
                studentIDTextbox.BackColor = Color.Red;
                return;
            }
            else
            {
                studentIDTextbox.BackColor = Color.White;
            }
            //search for student
            studentID = studentIDTextbox.Text;
            searchStudentID(studentID);
        }

        //add student button pressed under add grade
        private void addStudentButton_Click(object sender, EventArgs e)
        {
            //add studentID from previous panel if there
            if (studentIDTextbox.Text.Trim() != "")
            {
                newStudentIDTextbox.Text = studentIDTextbox.Text.Trim();
            }
            //panel visibility
            studentIDPanel.Visible = false;
            studentInfoPanel.Visible = false;
            addStudentPanel.Visible = true;
        }

        //save grade button pressed
        private void saveButton_Click(object sender, EventArgs e)
        {
            //Blank input validation checkers 
            Boolean isBlank = false;
            if (gradeTextbox.Visible == true)
            {
                if (gradeTextbox.Text.Equals("") || gradeTextbox.Text.Equals(" "))
                {
                    gradeTextbox.BackColor = Color.Red;
                    isBlank = true;
                }
                else
                {
                   gradeTextbox.BackColor = Color.White;
                }
            }
            if (studentIDTextbox.Text.Equals("") || studentIDTextbox.Text.Equals(" ")) {
                studentIDTextbox.BackColor = Color.Red;
                isBlank = true;
            } else {
                studentIDTextbox.BackColor = Color.White;
            }
            if (coursePrefixTextbox.Text.Equals("") || coursePrefixTextbox.Text.Equals(" "))
            {
                coursePrefixTextbox.BackColor = Color.Red;
                isBlank = true;
            } else {
                coursePrefixTextbox.BackColor = Color.White;
            } 
            if (courseNumberTextbox.Text.Equals("") || courseNumberTextbox.Text.Equals(" "))
            {
                courseNumberTextbox.BackColor = Color.Red;
                isBlank = true;
            }  else {
                courseNumberTextbox.BackColor = Color.White; 

            }
            if (yearTextbox.Text.Equals("") || yearTextbox.Text.Equals(" "))
            {
                yearTextbox.BackColor = Color.Red;
                isBlank = true;
            }  else {
                yearTextbox.BackColor = Color.White;
            }
            if (semesterTextbox.Text.Equals("") || semesterTextbox.Text.Equals(" "))
            {
                semesterTextbox.BackColor = Color.Red;
                isBlank = true;
            } else {
                semesterTextbox.BackColor = Color.White;
            }
            if (creditHoursTextbox.Text.Equals("") || creditHoursTextbox.Text.Equals(" "))
            {
                creditHoursTextbox.BackColor = Color.Red;
                return;
            } else {
                creditHoursTextbox.BackColor = Color.White;
                if (isBlank == true)
                {
                    return;
                }
            }

            Grade g = new Grade();
            g.studentID = studentIDTextbox.Text;
            g.coursePrefix = coursePrefixTextbox.Text;
            g.courseNum = courseNumberTextbox.Text;
            g.grade = gradeTextbox.Text;
            g.courseYear = yearTextbox.Text;
            g.semester = semesterTextbox.Text;
            g.hours = creditHoursTextbox.Text;
            //count is equal to which menu choice was chosen 
            if (count == 1)
            {
                //go to save grade function with grade object
                saveAddedGrade(g);
            } 
            else if (count == 2)
            {
                //go to edit grade function with grade object
                saveEditedGrade(g);
            }
            else if (count == 3)
            {
                //go to deleted grade function with grade object
                saveDeletedGrade(g);
            }
        }


        //save button pressed to add student
        private void newStudentSave_Click(object sender, EventArgs e)
        {
            //blank input validations
            Boolean isBlank = false;
            if (newStudentIDTextbox.Text.Equals("") || newStudentIDTextbox.Text.Equals(" "))
            {
                newStudentIDTextbox.BackColor = Color.Red;
                isBlank = true;
            } else
            {
                newStudentIDTextbox.BackColor = Color.White;
            }
            if (firstNameTextbox.Text.Equals("") || firstNameTextbox.Text.Equals(" "))
            {
                firstNameTextbox.BackColor = Color.Red;
                isBlank = true;
            } else
            {
                firstNameTextbox.BackColor = Color.White;
            }
            if (newStudentLastNameTextbox.Text.Equals("") || newStudentLastNameTextbox.Text.Equals(" "))
            {
                newStudentLastNameTextbox.BackColor = Color.Red;
                return;
            } else
            {
                newStudentLastNameTextbox.BackColor = Color.White;
                if (isBlank == true) {
                    return;
                } 
            }
            //add new student to student object
            Student s = new Student();
            s.studentID = newStudentIDTextbox.Text;
            firstName = firstNameTextbox.Text;
            lastName = newStudentLastNameTextbox.Text;
            s.name = firstName + " " + lastName;
            //send object to save new student function
            saveNewStudent(s);
        }


        //search for student id
        public void searchStudentID(string studentID) 
        {
            string constr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
            MySqlConnection conn = new MySqlConnection(constr);

            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();

                string str = "SELECT * FROM michaelstudentinfo WHERE studentID = @studentID";
                MySqlCommand cmd = new MySqlCommand(str, conn);
                //add in student id 
                cmd.Parameters.AddWithValue("@studentID", studentID);

                MySqlDataReader da = cmd.ExecuteReader();
                //read information from database
                if (da.Read())
                {
                    validStudentID = da["studentID"].ToString();
                    validName = da["name"].ToString();
                    validOverallGPA = da["GPA"].ToString();
                }
                da.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");

            //if student ID exists then
            if (studentID == validStudentID && count != 4)
            {
                //set studentID label to studentID 
                //set name label to name
                studentIDPanel.Visible = false;
                studentInfoPanel.Visible = true;
                studentIDLabel.Text = "Student ID: " + validStudentID;
                nameLabel.Text = "Student Name: " + validName;

                //load table
                refreshDataGridView();

            }
            else if (studentID == validStudentID && count == 4) //if student exists and generate pdf button pressed
            {
                //refresh datagrid
                refreshDataGridView();
                generatePDF();
            }

            //if student ID DOES NOT exist AND add grade button pressed
            else if (studentID != validStudentID && count == 1)
            {
                //show error message with add student option
                MessageBox.Show("No Student ID Found. Please try again or add a new student.", "No Student Found");
                addStudentButton.Visible = true;
            }
            //if student ID does not exist and we pressed edit/delete button
            else
            {
                //show error message
                MessageBox.Show("No Student ID Found. Please try again.", "No Student Found");
            }
        }

        //add new Student 
        public void saveNewStudent(Student s) 
        {
            double overallGPA = 0.00;

            string connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();

                //select information
                string sql = "SELECT * FROM michaelstudentinfo WHERE studentID = @studentID";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@studentID", s.studentID);
                //see if there exists student id already 
                int exists = Convert.ToInt32(cmd.ExecuteScalar());

                //if it exists - report error
                if (exists != 0)
                {
                    newStudentIDTextbox.Text = "";
                    firstNameTextbox.Text = "";
                    newStudentLastNameTextbox.Text = "";
                    //show error message
                    MessageBox.Show("Student ID already exists in database. Save NOT Successful.", "Error");
                }
                //if not - add student to database
                else
                {
                    //insert new student into database
                    string sql1 = "INSERT INTO michaelstudentinfo (studentID, name, GPA) VALUES (@studentID, @name, @GPA)";
                    MySqlCommand cmd1 = new MySqlCommand(sql1, conn);
                    cmd1.Parameters.AddWithValue("@studentID", s.studentID);
                    cmd1.Parameters.AddWithValue("@name", s.name);
                    cmd1.Parameters.AddWithValue("@GPA", overallGPA);
                    cmd1.ExecuteNonQuery();
                    //show success message
                    MessageBox.Show("New student added successfully.", "Success");
                    addStudentPanel.Visible = false;
                    studentInfoPanel.Visible = true;
                    studentIDLabel.Text = "Student ID: " + s.studentID;
                    nameLabel.Text = "Student Name: " + s.name;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");
        } //end of



        //update grid view table
        public void refreshDataGridView() {
            string connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
            MySqlConnection conn = new MySqlConnection(connStr);

            if (count != 4) { //not generate transcript
            //load grade data into datagridview
                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    conn.Open();

                    //select information from database
                    string str = "SELECT * FROM michaelstudentgrades WHERE studentID = @studentID";
                    MySqlCommand cmd = new MySqlCommand(str, conn);

                    cmd.Parameters.AddWithValue("@studentID", studentID);

                    //read dataset and load into grid view
                    MySqlDataReader da = cmd.ExecuteReader();
                    DataSet ds = new DataSet();
                    DataTable dataTable = new DataTable();
                    ds.Tables.Add(dataTable);
                    dataTable.Load(da);

                    //customize data grid column headers
                    gradesDataGridView.DataSource = ds.Tables[0];
                    gradesDataGridView.Columns[0].Visible = false;
                    gradesDataGridView.Columns[1].HeaderText = "Course Prefix";
                    gradesDataGridView.Columns[2].HeaderText = "Course Number";
                    gradesDataGridView.Columns[3].HeaderText = "Grade";
                    gradesDataGridView.Columns[4].HeaderText = "Year";
                    gradesDataGridView.Columns[5].HeaderText = "Semester";
                    da.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                conn.Close();
                Console.WriteLine("Done.");
            } else  { //else it's generate transcript
                //load grade data into datagridview
                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    conn.Open();

                    //need to search where grade != a deleted grade so we don't include that in data table = datagridview 
                    string str = "SELECT * FROM michaelstudentgrades WHERE studentID = @studentID AND grade != @grade";
                    MySqlCommand cmd = new MySqlCommand(str, conn);

                    cmd.Parameters.AddWithValue("@studentID", studentID);
                    cmd.Parameters.AddWithValue("@grade", "_");

                    //read dataset and load into grid view
                    MySqlDataReader da = cmd.ExecuteReader();
                    DataSet ds = new DataSet();
                    DataTable dataTable = new DataTable();
                    ds.Tables.Add(dataTable);
                    dataTable.Load(da);

                    //customize datagrid column headers
                    gradesDataGridView.DataSource = ds.Tables[0];
                    gradesDataGridView.Columns[0].Visible = false;
                    gradesDataGridView.Columns[1].HeaderText = "Course Prefix";
                    gradesDataGridView.Columns[2].HeaderText = "Course Number";
                    gradesDataGridView.Columns[3].HeaderText = "Grade";
                    gradesDataGridView.Columns[4].HeaderText = "Year";
                    gradesDataGridView.Columns[5].HeaderText = "Semester";
                    da.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                conn.Close();
                Console.WriteLine("Done.");
            }

        }

        //save added grade
        public void saveAddedGrade(Grade g)
        {
            string connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
            MySqlConnection conn = new MySqlConnection(connStr);

            //number validation for courseNum & hours and character validation for grade
            int value;
            if ((!Int32.TryParse(g.courseNum, out value) || !Int32.TryParse(g.courseYear, out value) || !Int32.TryParse(g.hours, out value)) || (g.grade != "A" && g.grade != "B" && g.grade != "C" && g.grade != "D" && g.grade != "F" && g.grade != "_"))
            {
                MessageBox.Show("Grade NOT added successfully. There was an error in your input.", "Error");
            } else {

                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    conn.Open();

                    string sql = "SELECT * FROM michaelstudentgrades WHERE studentID = @studentID AND coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester ";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);

                    cmd.Parameters.AddWithValue("@studentID", g.studentID);
                    cmd.Parameters.AddWithValue("@coursePrefix", g.coursePrefix);
                    cmd.Parameters.AddWithValue("@courseNum", g.courseNum);
                    cmd.Parameters.AddWithValue("@courseYear", g.courseYear);
                    cmd.Parameters.AddWithValue("@semester", g.semester);

                    int exists = Convert.ToInt32(cmd.ExecuteScalar());
                    if (exists != 0)
                    {
                        //show error message, clear textboxes
                        clearEnteredText();
                        MessageBox.Show("There is already a grade for this course in the database.", "Error");
                    }
                    else
                    {
                        //search course if it exists first
                        searchCourse(g.coursePrefix, g.courseNum, g.courseYear, g.semester, creditHoursTextbox.Text);

                        //insert new data into database
                        string sql1 = "INSERT INTO michaelstudentgrades (studentID, coursePrefix, courseNum, grade, courseYear, semester) VALUES (@studentID, @coursePrefix, @courseNum, @grade, @courseYear, @semester)";
                        MySqlCommand cmd1 = new MySqlCommand(sql1, conn);
                        cmd1.Parameters.AddWithValue("@studentID", g.studentID);
                        cmd1.Parameters.AddWithValue("@coursePrefix", g.coursePrefix);
                        cmd1.Parameters.AddWithValue("@courseNum", g.courseNum);
                        cmd1.Parameters.AddWithValue("@grade", g.grade);
                        cmd1.Parameters.AddWithValue("@courseYear", g.courseYear);
                        cmd1.Parameters.AddWithValue("@semester", g.semester);
                        cmd1.ExecuteNonQuery();
                        //refresh datagrid view, show success message, clear textboxes
                        refreshDataGridView();
                        MessageBox.Show("New grade added successfully.", "Success");
                        clearEnteredText();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                conn.Close();
                Console.WriteLine("Done.");

            }
        } //end of save added grade function


        //save edited grade
        public void saveEditedGrade(Grade g)
        {
            //number validation for courseNum & hours and character validation for grade
            int value;
            if ((!Int32.TryParse(g.courseNum, out value) || !Int32.TryParse(g.courseYear, out value) || !Int32.TryParse(g.hours, out value)) || (g.grade != "A" && g.grade != "B" && g.grade != "C" && g.grade != "D" && g.grade != "F" && g.grade != "_"))
            {
                //show error message
                MessageBox.Show("Grade NOT edited successfully. There was an error in your input.", "Error");
            } else {
                string connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
                MySqlConnection conn = new MySqlConnection(connStr);
                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    conn.Open();

                    //select information from database
                    string sql = "SELECT * FROM michaelstudentgrades WHERE studentID = @studentID AND coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester ";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);

                    cmd.Parameters.AddWithValue("@studentID", g.studentID);
                    cmd.Parameters.AddWithValue("@coursePrefix", g.coursePrefix);
                    cmd.Parameters.AddWithValue("@courseNum", g.courseNum);
                    cmd.Parameters.AddWithValue("@courseYear", g.courseYear);
                    cmd.Parameters.AddWithValue("@semester", g.semester);
                    //read the data from the database
                    int exists = Convert.ToInt32(cmd.ExecuteScalar());

                    if (exists != 0)
                    {
                        //update database 
                        string sql1 = "UPDATE michaelstudentgrades SET grade = @grade WHERE studentID = @studentID AND coursePrefix = @coursePrefix AND courseNum = @courseNum AND semester = @semester AND courseYear = @courseYear";
                        MySqlCommand cmd1 = new MySqlCommand(sql1, conn);
                        cmd1.Parameters.AddWithValue("@studentID", g.studentID);
                        cmd1.Parameters.AddWithValue("@coursePrefix", g.coursePrefix);
                        cmd1.Parameters.AddWithValue("@courseNum", g.courseNum);
                        cmd1.Parameters.AddWithValue("@grade", g.grade);
                        cmd1.Parameters.AddWithValue("@courseYear", g.courseYear);
                        cmd1.Parameters.AddWithValue("@semester", g.semester);
                        cmd1.ExecuteNonQuery();

                        //refresh datagrid view, show success message, clear textboxes
                        refreshDataGridView();
                        MessageBox.Show("Grade was changed successfully.", "Success");
                        clearEnteredText();
                    }
                    else
                    {
                        //show error message and clear textbox
                        clearEnteredText();
                        MessageBox.Show("A grade does not exist for this course under this student.", "Error");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                conn.Close();
                Console.WriteLine("Done.");

            }
        } //end of save edited grade function


        //save deleted grade
        public void saveDeletedGrade(Grade g)
        {
            //number validation for courseNum & hours and character validation for grade
            int value;
            if ((!Int32.TryParse(g.courseNum, out value) || !Int32.TryParse(g.courseYear, out value) || !Int32.TryParse(g.hours, out value)))
            {
                //show error message
                MessageBox.Show("Grade NOT deleted successfully. There was an error in your input.", "Error");
            } else {
                string connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
                MySqlConnection conn = new MySqlConnection(connStr);
                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    conn.Open();

                    //select information from database
                    string sql = "SELECT * FROM michaelstudentgrades WHERE studentID = @studentID AND coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester ";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);

                    cmd.Parameters.AddWithValue("@studentID", g.studentID);
                    cmd.Parameters.AddWithValue("@coursePrefix", g.coursePrefix);
                    cmd.Parameters.AddWithValue("@courseNum", g.courseNum);
                    cmd.Parameters.AddWithValue("@courseYear", g.courseYear);
                    cmd.Parameters.AddWithValue("@semester", g.semester);
                    //read the data from the database
                    int exists = Convert.ToInt32(cmd.ExecuteScalar());

                    if (exists != 0)
                    {
                        //update database tables
                        string sql1 = "UPDATE michaelstudentgrades SET grade = @grade WHERE studentID = @studentID AND coursePrefix = @coursePrefix AND courseNum = @courseNum AND semester = @semester AND courseYear = @courseYear";
                        MySqlCommand cmd1 = new MySqlCommand(sql1, conn);
                        cmd1.Parameters.AddWithValue("@studentID", g.studentID);
                        cmd1.Parameters.AddWithValue("@coursePrefix", g.coursePrefix);
                        cmd1.Parameters.AddWithValue("@courseNum", g.courseNum);
                        cmd1.Parameters.AddWithValue("@grade", "_");
                        cmd1.Parameters.AddWithValue("@courseYear", g.courseYear);
                        cmd1.Parameters.AddWithValue("@semester", g.semester);
                        cmd1.ExecuteNonQuery();
                        //refresh datagrid view, show success message, clear textboxes
                        refreshDataGridView();
                        MessageBox.Show("The grade was deleted successfully.", "Success");
                        clearEnteredText();
                    }
                    else
                    {
                        // show error message and clear textboxes
                        clearEnteredText();
                        MessageBox.Show("A grade does not exist for this course under this student.", "Error");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                conn.Close();
                Console.WriteLine("Done.");
            }
        } //end of save deleted grade function


        //generate and save pdf
        public void generatePDF()
        {
            validOverallGPA = calculateGPA(studentID).ToString();

            if (gradesDataGridView.Rows.Count > 0)
            {
                //data grid columns
                gradesDataGridView.Columns.RemoveAt(0);
                gradesDataGridView.Columns[0].HeaderText = "Course Prefix";
                gradesDataGridView.Columns[1].HeaderText = "Course Number";
                gradesDataGridView.Columns[2].HeaderText = "Grade";
                gradesDataGridView.Columns[3].HeaderText = "Year";
                gradesDataGridView.Columns[4].HeaderText = "Semester";

                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "PDF (*.pdf)|*.pdf";
                sfd.FileName = validName + " Transcript.pdf";
                bool fileError = false;
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(sfd.FileName))
                    {
                        try
                        {
                            File.Delete(sfd.FileName);
                        }
                        catch (IOException ex)
                        {
                            fileError = true;
                            MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                        }
                    }
                    if (!fileError)
                    {
                        try
                        {
                            //create table to display student records
                            PdfPTable pdfTable = new PdfPTable(gradesDataGridView.Columns.Count);
                            pdfTable.DefaultCell.Padding = 3;
                            pdfTable.WidthPercentage = 100;
                            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            //get data
                            foreach (DataGridViewColumn column in gradesDataGridView.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));
                                pdfTable.AddCell(cell);
                            }

                            foreach (DataGridViewRow row in gradesDataGridView.Rows)
                            {
                                foreach (DataGridViewCell cell in row.Cells)
                                {
                                    pdfTable.AddCell(cell.Value.ToString());
                                }
                            }
                            
                            //create second table for student information title
                            PdfPTable table2 = new PdfPTable(1);
                            PdfPCell cell2 = new PdfPCell(new Phrase(validName + " Transcript " + "\nStudent ID: " + studentID + "\n GPA: " + validOverallGPA + "\n "));
                            cell2.HorizontalAlignment = Element.ALIGN_CENTER;
                            cell2.Colspan = 2;
                            cell2.BorderWidth = 0;
                            table2.AddCell(cell2);


                            using (FileStream stream = new FileStream(sfd.FileName, FileMode.Create))
                            {
                                //add tables to pdf to create
                                Document pdfDoc = new Document(PageSize.A4, 10f, 20f, 20f, 10f);
                                PdfWriter.GetInstance(pdfDoc, stream);
                                pdfDoc.Open();
                                pdfDoc.Add(table2);
                                pdfDoc.Add(pdfTable);
                                pdfDoc.Close();
                                stream.Close();
                            }

                            MessageBox.Show("Transcript saved successfully. Press OK to automatically open transcript.", "Success");
                            //automatically start pdf
                            Process.Start(sfd.FileName);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error :" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No grade records to export.", "No Records");
            }
        } //end of generatepdf function


        //search course history
        public void searchCourse(string coursePrefix, string courseNumber, string courseYear, string semester, string hours)
        {
            string connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
            //string connStr = "server=127.0.0.1;user=root;database=testing;port=3306;";
            MySqlConnection conn = new MySqlConnection(connStr);

            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();

                string sql = "SELECT * FROM michaelcoursehours WHERE coursePrefix = @coursePrefix AND courseNum = @courseNum AND courseYear = @courseYear AND semester = @semester AND hours = @hours ";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@coursePrefix", coursePrefix);
                cmd.Parameters.AddWithValue("@courseNum", courseNumber);
                cmd.Parameters.AddWithValue("@courseYear", courseYear);
                cmd.Parameters.AddWithValue("@semester", semester);
                cmd.Parameters.AddWithValue("@hours", hours);
                //read the data from the database
                int exists = Convert.ToInt32(cmd.ExecuteScalar());

                if (exists == 0)
                {
                    string sql2 = "INSERT INTO michaelcoursehours (coursePrefix, courseNum, courseYear, semester, hours) VALUES ( @coursePrefix, @courseNum, @courseYear, @semester, @hours)";
                    MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
                    cmd2.Parameters.AddWithValue("@coursePrefix", coursePrefix);
                    cmd2.Parameters.AddWithValue("@courseNum", courseNumber);
                    cmd2.Parameters.AddWithValue("@courseYear", courseYear);
                    cmd2.Parameters.AddWithValue("@semester", semester);
                    cmd2.Parameters.AddWithValue("@hours", hours);
                    cmd2.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");
        } //end search course history class

        public string[] fileNameBreakdown(String i)
        {

            String[] outp = new String[4];
            //outp[0] = "111";
            //outp[4] = "1234";
            i = i.Substring(i.IndexOf('\\') + 1);

            i = i.Substring(i.IndexOf('\\') + 1);

            i = i.Substring(i.IndexOf('\\') + 1);


            outp[0] = i.Substring(0, i.IndexOf(' '));//Course Prefix

            i = i.Substring(i.IndexOf(' ') + 1);
            outp[3] = i.Substring(0, i.IndexOf(' '));//Number
            i = i.Substring(i.IndexOf(' ') + 1);
            outp[2] = i.Substring(0, i.IndexOf(' '));//Year
            i = i.Substring(i.IndexOf(' ') + 1);
            outp[1] = i.Substring(0, i.Length - 5);//Semester
            return outp;
        }



        //calculate gpa function
        public double calculateGPA(String studentID)
        {

            int totalHours = 0; //total hours taken
            double calculatedGPA = 0; //used to calculate GPA by taking (total of weighted grades)/ (total hours taken)

            DataTable myTable = new DataTable();
            string connStr = "server=157.89.28.29;user=student;database=csc340_db;port=3306;password=Maroon@21?;";
            //string connStr = "server=127.0.0.1;user=root;database=testing;port=3306;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();

                string sql = "SELECT s.StudentID, i.coursePrefix, i.courseNum, i.semester, i.courseYear, g.hours, i.grade FROM michaelstudentgrades i JOIN michaelcoursehours g JOIN michaelstudentinfo s ON g.coursePrefix = i.coursePrefix AND g.courseNum = i.courseNum AND g.courseYear = i.courseYear AND g.semester = i.semester AND s.StudentID = i.studentID WHERE i.studentID = @studentID; ";
                //string sql = "SELECT s.StudentID, i.coursePrefix, i.courseNumber, i.semester, i.year, g.hours, i.grade FROM michaelstudentgrades i JOIN dhk_courseinfo g JOIN michaelstudentinfo s ON g.coursePrefix = i.coursePrefix AND g.courseNumber = i.courseNumber AND g.courseYear = i.courseYear AND g.semester = i.semester AND s.StudentID = i.studentID WHERE i.studentID = @studentID; ";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@studentID", studentID);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);

                if (myTable.Rows.Count != 0)
                {
                    foreach (DataRow row in myTable.Rows)
                    {
                        if (row["grade"].Equals("_"))
                        {
                            //do nothing
                        } 
                        else {
                            totalHours += int.Parse(row["hours"].ToString()); //add hours

                            if (row["grade"].Equals("A")) //determine weight of the current grade
                            {
                                calculatedGPA += 4 * int.Parse(row["hours"].ToString());
                            }
                            else if (row["grade"].Equals("B"))
                            {
                                calculatedGPA += 3 * int.Parse(row["hours"].ToString());
                            }
                            else if (row["grade"].Equals("C"))
                            {
                                calculatedGPA += 2 * int.Parse(row["hours"].ToString());
                            }
                            else if (row["grade"].Equals("D"))
                            {
                                calculatedGPA += 1 * int.Parse(row["hours"].ToString());
                            }

                        }

                    }
                    calculatedGPA = Math.Round((calculatedGPA / totalHours), 2); //perform GPA calculation
                }
                else
                {
                    calculatedGPA = -1; // NO GRADES
                }
                //add in gpa
                string sql2 = "UPDATE michaelstudentinfo SET GPA = @GPA WHERE studentID = @studentID";
                MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
                cmd2.Parameters.AddWithValue("@studentID", studentID);
                cmd2.Parameters.AddWithValue("@GPA", calculatedGPA);
                cmd2.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            conn.Close();
            return calculatedGPA;
        } //end of calculate GPA function

        //clear textboxes for multiple entries
        public void clearEnteredText()
        {
            //clear out texts and colors
            coursePrefix = "";
            courseNum = "";
            year = "";
            semester = "";
            grade = "";
            coursePrefixTextbox.Clear();
            courseNumberTextbox.Clear();
            yearTextbox.Clear();
            semesterTextbox.Clear();
            gradeTextbox.Clear();
            firstNameTextbox.Clear();
            newStudentLastNameTextbox.Clear();
            newStudentIDTextbox.Clear();
            creditHoursTextbox.Clear();
            studentIDTextbox.BackColor = Color.White;
            coursePrefixTextbox.BackColor = Color.White;
            courseNumberTextbox.BackColor = Color.White;
            gradeTextbox.BackColor = Color.White;
            yearTextbox.BackColor = Color.White;
            semesterTextbox.BackColor = Color.White;
            creditHoursTextbox.BackColor = Color.White;
        } //end of clear entered text function 
    }
}
